@interface MPVideoView : UIView

@end
