@interface PLManagedAsset : NSObject

- (UIImage *)newFullSizeImage;

@end
