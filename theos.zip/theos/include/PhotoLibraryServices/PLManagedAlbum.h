@interface PLManagedAlbum : NSObject

@property (nonatomic, retain) NSOrderedSet *assets;

@end
