@interface CLPlacemark : NSObject

@property (readonly) NSDictionary *addressDictionary;

@end
