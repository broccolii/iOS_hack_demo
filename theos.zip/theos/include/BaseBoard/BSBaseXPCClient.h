@interface BSBaseXPCClient : NSObject

@end
