@interface NSXPCInterface : NSObject

+ (id)interfaceWithProtocol:(id)arg1;

@end