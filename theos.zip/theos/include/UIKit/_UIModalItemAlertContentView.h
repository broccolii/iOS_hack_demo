#import "_UIModalItemContentView.h"

@interface _UIModalItemAlertContentView : _UIModalItemContentView

@end
