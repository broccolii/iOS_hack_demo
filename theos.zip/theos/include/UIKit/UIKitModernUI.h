extern BOOL _UIApplicationUsesLegacyUI();
