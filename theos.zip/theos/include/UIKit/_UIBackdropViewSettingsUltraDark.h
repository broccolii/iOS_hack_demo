#import "_UIBackdropViewSettings.h"

@interface _UIBackdropViewSettingsUltraDark : _UIBackdropViewSettings

@end
