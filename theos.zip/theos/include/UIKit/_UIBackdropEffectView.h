@interface _UIBackdropEffectView : UIView

@end
