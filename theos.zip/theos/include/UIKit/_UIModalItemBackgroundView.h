@interface _UIModalItemBackgroundView : UIView

@end
