#import "UIKBRenderConfig.h"

@interface UIKBRenderFactoryiPhonePasscode : UIKBRenderConfig

@end
