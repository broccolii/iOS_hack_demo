#import "_UIModalItemBackgroundView.h"

@interface _UIModalItemAlertBackgroundView : _UIModalItemBackgroundView

@end
