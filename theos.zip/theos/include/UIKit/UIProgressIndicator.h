@interface UIProgressIndicator : UIActivityIndicatorView

@end
