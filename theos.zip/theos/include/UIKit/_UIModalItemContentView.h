@interface _UIModalItemContentView : UIView

@property (readonly, nonatomic) UILabel *messageLabel;
@property (readonly, nonatomic) UILabel *subtitleLabel;
@property (readonly, nonatomic) UILabel *titleLabel;

@end
