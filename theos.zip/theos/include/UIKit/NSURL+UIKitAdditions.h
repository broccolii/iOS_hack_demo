@interface NSURL (UIKitAdditions)

- (instancetype)itmsURL;

@end
