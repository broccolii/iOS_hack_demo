#import "UIKBRenderConfig.h"

@interface UIKBRenderFactoryiPadPasscode : UIKBRenderConfig

@end
