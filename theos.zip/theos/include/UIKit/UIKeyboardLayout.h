@class UIKBRenderConfig;

@interface UIKeyboardLayout : NSObject

@property (nonatomic, retain) UIKBRenderConfig *renderConfig;
@property CGFloat passcodeOutlineAlpha;

@end
