@interface UIKBRenderConfig : NSObject

+ (instancetype)darkConfig;
+ (instancetype)defaultConfig;

@property CGFloat keycapOpacity;

@end
