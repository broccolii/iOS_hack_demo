@interface UIDevice (Private)

@property (nonatomic, readonly) BOOL _supportsForceTouch;

@end
