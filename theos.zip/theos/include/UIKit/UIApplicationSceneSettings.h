#import <FrontBoard/FBSSceneSettings.h>

@interface UIApplicationSceneSettings : FBSSceneSettings

@property (nonatomic, readonly) BOOL idleModeEnabled;

@end
