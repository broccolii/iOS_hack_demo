#import <FrontBoard/FBSMutableSceneSettings.h>

@interface UIMutableApplicationSceneSettings : FBSMutableSceneSettings

@property (nonatomic) BOOL idleModeEnabled;

@end
