@interface _UIModalItemTableViewCell : UITableViewCell

@end
