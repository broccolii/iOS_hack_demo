#import "UIKeyboardLayout.h"

@interface UIKeyboardLayoutStar : UIKeyboardLayout

@end
