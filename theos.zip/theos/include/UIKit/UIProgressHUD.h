@interface UIProgressHUD : UIView

@end
