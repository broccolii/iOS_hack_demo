@interface UIActivity (Private)

+ (UIImage *)_activityImageForApplication:(NSString *)bundleIdentifier;

@end
