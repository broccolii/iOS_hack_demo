@interface UIKeyboardCache : NSObject

+ (instancetype)sharedInstance;

@end
