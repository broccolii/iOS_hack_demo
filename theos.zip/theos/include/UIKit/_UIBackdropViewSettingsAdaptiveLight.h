#import "_UIBackdropViewSettingsLight.h"

@interface _UIBackdropViewSettingsAdaptiveLight : _UIBackdropViewSettingsLight

@end
