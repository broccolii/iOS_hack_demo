#import "_UIBackdropViewSettings.h"

@interface _UIBackdropViewSettingsLight : _UIBackdropViewSettings

@end
