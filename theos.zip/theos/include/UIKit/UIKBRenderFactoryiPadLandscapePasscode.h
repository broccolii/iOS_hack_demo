#import "UIKBRenderConfig.h"

@interface UIKBRenderFactoryiPadLandscapePasscode : UIKBRenderConfig

@end
