@interface _UIActivityGroupListViewController : UICollectionViewController

@property (nonatomic, copy) NSArray *activityGroupViewControllers;

@end
