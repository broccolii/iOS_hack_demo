@interface UIActivityGroupViewController : UICollectionViewController

@end
