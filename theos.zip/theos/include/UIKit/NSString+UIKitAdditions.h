@interface NSString (UIKitAdditions)

@property (nonatomic, retain) NSDictionary *queryKeysAndValues; // why is this private :(

@end
