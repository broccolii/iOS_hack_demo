// app

@interface WorldClockPadViewController : UIViewController

@end
