// app

@class WorldClockCollectionView;

@interface WorldClockPadContentView : UIView

@property (readonly, assign, nonatomic) WorldClockCollectionView *clocksView;

@end
