// framework

@interface WorldClockCity : NSObject

@property (readonly) NSString *name;

@end
