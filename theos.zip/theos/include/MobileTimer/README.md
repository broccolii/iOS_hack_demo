(A note about this directory: there is both `MobileTimer.app` and `MobileTimer.framework`, therefore headers are commented to say whether they're from the app or framework.)
