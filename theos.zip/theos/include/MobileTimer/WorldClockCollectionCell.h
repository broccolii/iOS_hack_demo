// app

@class WorldClockView;

#import <UIkit/UICollectionViewCell.h>

@interface WorldClockCollectionCell : UICollectionViewCell

@property (retain, nonatomic) WorldClockView *clockView;

@end
