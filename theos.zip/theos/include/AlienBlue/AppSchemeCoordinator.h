@interface AppSchemeCoordinator : NSObject

+ (void)openRedditThreadUrl:(NSString *)url;

@end
