@interface AlienBlueAppDelegate : NSObject <UIApplicationDelegate>

@property (nonatomic, retain) UIWindow *window;

@end
