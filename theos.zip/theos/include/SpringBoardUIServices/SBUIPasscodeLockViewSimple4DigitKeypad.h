@interface SBUIPasscodeLockViewSimple4DigitKeypad : UIView

@property (nonatomic) CGFloat backgroundAlpha;

- (instancetype)initWithLightStyle:(BOOL)lightStyle;

@end
