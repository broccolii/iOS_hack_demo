@interface SchemeManager : NSObject

+ (void)handleVideoOpen:(NSURL *)url;

@end
