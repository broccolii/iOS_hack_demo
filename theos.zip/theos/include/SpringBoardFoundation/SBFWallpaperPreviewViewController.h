@interface SBFWallpaperPreviewViewController : UIViewController

- (instancetype)initWithImage:(UIImage *)image;

@end
