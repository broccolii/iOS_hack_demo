@interface SBFWallpaperParallaxSettings : NSObject

+ (CGSize)minimumWallpaperSizeForCurrentDevice;

@end
