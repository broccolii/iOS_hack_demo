@interface NowPlayingDrawerCell : UITableViewCell

@property (nonatomic, retain) UIImageView *leftImageView;

@end
