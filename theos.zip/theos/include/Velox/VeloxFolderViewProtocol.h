@protocol VeloxFolderViewProtocol

+ (int)folderHeight;

- (instancetype)initWithFrame:(CGRect)frame;

@optional
- (void)unregisterFromStuff;

@end
