#import "SBNotificationCell.h"

@class SBLockScreenActionContext;

@interface SBLockScreenNotificationCell : SBNotificationCell

@property (nonatomic, retain) SBLockScreenActionContext *lockScreenActionContext;

@end
