@interface SBControlCenterController : NSObject

+ (instancetype)sharedInstance;

@end
