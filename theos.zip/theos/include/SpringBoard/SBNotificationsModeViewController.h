@interface SBNotificationsModeViewController : UIViewController

@end
