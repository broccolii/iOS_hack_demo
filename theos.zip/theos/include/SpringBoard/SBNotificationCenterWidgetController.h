@interface SBNotificationCenterWidgetController : NSObject

+ (NSString *)containingBundleIdentifierForWidgetWithBundleIdentifer:(NSString *)identifier;

@end
