@interface SBDockView : UIView

- (void)setBackgroundAlpha:(CGFloat)backgroundAlpha;

@end
