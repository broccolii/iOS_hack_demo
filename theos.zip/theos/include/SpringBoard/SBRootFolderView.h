#import "SBFolderView.h"

@class SBDockView;

@interface SBRootFolderView : SBFolderView

@property (nonatomic, retain, readonly) SBDockView *dockView;

@end
