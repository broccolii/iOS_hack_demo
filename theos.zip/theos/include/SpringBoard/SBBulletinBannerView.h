#import "SBBannerView.h"

@interface SBUIRoundedBannerItemView : UIView // iOS 6 only, but the compiler doesn't need to know that yet.
@end

NS_CLASS_AVAILABLE_IOS(6_0) @interface SBBulletinBannerView : SBUIRoundedBannerItemView

@end
