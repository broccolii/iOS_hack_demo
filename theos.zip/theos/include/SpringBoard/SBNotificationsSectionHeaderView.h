@interface SBNotificationsSectionHeaderView : UITableViewHeaderFooterView

@end
