@interface SBDisplayItem : NSObject

@property (nonatomic, retain, readonly) NSString *type;
@property (nonatomic, retain, readonly) NSString *displayIdentifier;

@end
