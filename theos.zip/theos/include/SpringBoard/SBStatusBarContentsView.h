@interface SBStatusBarContentsView : NSObject

@end
