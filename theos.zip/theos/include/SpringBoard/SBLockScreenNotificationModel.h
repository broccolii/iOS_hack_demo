@class SBAwayBulletinListItem;

@protocol SBLockScreenNotificationModel

- (SBAwayBulletinListItem *)listItemAtIndexPath:(NSIndexPath *)indexPath;

@end
