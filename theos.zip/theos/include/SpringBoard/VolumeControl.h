@interface VolumeControl : NSObject

- (void)increaseVolume;
- (void)decreaseVolume;

@end
