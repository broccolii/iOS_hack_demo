@interface SBFolderSlidingView : UIView

@end
