@interface SBSearchViewController : NSObject

+ (instancetype)sharedInstance;

@property BOOL isVisible;

@end
