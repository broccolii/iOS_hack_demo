@interface SBIconList : UIView

@end
