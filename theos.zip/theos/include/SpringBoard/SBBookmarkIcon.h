@interface SBBookmarkIcon : NSObject

@end
