@interface SBWidgetApplicationIcon : NSObject

@end
