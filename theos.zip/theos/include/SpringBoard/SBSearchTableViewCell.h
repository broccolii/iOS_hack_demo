@interface SBSearchTableViewCell : UITableViewCell

@end
