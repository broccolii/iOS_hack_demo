@interface SBIconLabel : UIControl

@property BOOL inDock;

@end
