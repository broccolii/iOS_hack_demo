@interface SBAwayView : UIView

@end
