@interface AVQueue : NSObject

@end
