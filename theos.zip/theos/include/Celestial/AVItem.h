@interface AVItem : NSObject

@end
