#import "CKTypingIndicatorLayer.h"

@interface CKTypingView : UIView

@property (nonatomic, readonly, retain) CKTypingIndicatorLayer *layer;

@end
