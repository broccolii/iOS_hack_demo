@interface CKTypingIndicatorLayer : CALayer

- (void)startGrowAnimation;
- (void)startPulseAnimation;
- (void)startShrinkAnimation;

@end
