@interface CKConversationList : NSObject {
	NSMutableArray *_trackedConversations;
}

@end
