@class CKConversation;

@interface CKTranscriptRecipientsController : UITableViewController

@property (nonatomic, retain) CKConversation *conversation;

@end
