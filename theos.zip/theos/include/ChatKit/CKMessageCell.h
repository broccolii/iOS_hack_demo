@interface CKMessageCell : UITableViewCell

@end
