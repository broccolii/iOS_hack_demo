#import "CKViewController.h"

@interface CKTranscriptManagementController : CKViewController

- (instancetype)initWithConversation:(CKConversation *)conversation;

@end
