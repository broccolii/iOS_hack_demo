#import <FrontBoard/FBSSceneSettings.h>

@interface FBSMutableSceneSettings : FBSSceneSettings

- (void)setBackgrounded:(BOOL)backgrounded;

@end
