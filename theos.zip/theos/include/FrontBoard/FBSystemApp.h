#import <sys/cdefs.h>

__BEGIN_DECLS

extern NSString *FBSystemAppBundleID();

__END_DECLS
