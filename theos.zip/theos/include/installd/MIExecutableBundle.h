#import "MIBundle.h"

@interface MIExecutableBundle : MIBundle

@end
