@interface IMServiceImpl : NSObject

+ (instancetype)iMessageService;

@end
