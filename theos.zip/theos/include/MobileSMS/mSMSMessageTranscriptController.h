@interface mSMSMessageTranscriptController : NSObject

@end
