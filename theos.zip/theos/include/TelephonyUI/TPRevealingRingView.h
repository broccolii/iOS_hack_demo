@interface TPRevealingRingView : UIView

@property (nonatomic, readonly) struct UIEdgeInsets paddingOutsideRing;

@property (nonatomic, readonly) CGSize ringSize;

@end
