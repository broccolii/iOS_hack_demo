#import <BaseBoard/BSBaseXPCClient.h>

@interface BKSProcessAssertionClient : BSBaseXPCClient

+ (instancetype)sharedInstance;

@end
