#undef NS_AVAILABLE_MAC
#undef NS_CLASS_AVAILABLE_MAC
#define NS_AVAILABLE_MAC(...)
#define NS_CLASS_AVAILABLE_MAC(...)

#define NSRect CGRect
#define NSPoint CGPoint
#define NSSize CGSize
