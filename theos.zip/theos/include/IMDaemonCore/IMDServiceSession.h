@interface IMDServiceSession : NSObject

@end
