#import <CoreLocation/CLPlacemark.h>

@interface MKPlacemark : CLPlacemark

@end
