@interface RecentCall : NSObject

- (int)type;

@end
