@class RecentCall;

@interface RecentsTableViewCell : UITableViewCell

- (RecentCall *)call;

@end
