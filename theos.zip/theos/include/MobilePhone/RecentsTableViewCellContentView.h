@interface RecentsTableViewCellContentView : UIView

@end
