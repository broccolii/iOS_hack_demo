#include <sys/cdefs.h>

__BEGIN_DECLS
extern NSString *PLLocalizedFrameworkString(NSString *key, NSString *comment);
__END_DECLS
