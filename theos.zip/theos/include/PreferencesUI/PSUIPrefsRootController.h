#import <Preferences/PSRootController.h>

@interface PSUIPrefsRootController : PSRootController

@end
