@interface SKUIScrollingSegmentedController : UIViewController

@end
