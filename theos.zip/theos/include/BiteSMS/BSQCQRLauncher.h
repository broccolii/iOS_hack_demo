@interface BSQCQRLauncher : NSObject

+ (void)showQuickCompose:(BOOL)isLocked;

@end
