@interface PSDiscreteSlider : UISlider

@property (nonatomic, retain) UIColor *trackMarkersColor;

@end
