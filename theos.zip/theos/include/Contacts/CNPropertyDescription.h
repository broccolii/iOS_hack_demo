@interface CNPropertyDescription : NSObject

@property (nonatomic, copy, readonly) NSString *key;

@end
