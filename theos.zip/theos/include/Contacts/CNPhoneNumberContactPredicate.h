#import "CNPredicate.h"

@interface CNPhoneNumberContactPredicate : CNPredicate

@end
