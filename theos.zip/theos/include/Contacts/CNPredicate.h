@interface CNPredicate : NSPredicate

@end
