#ifndef __LOGOS_H
#define __LOGOS_H

// As an unfortunate matter of course, logos/logos.h can not include any preprocessor definitions that are to be used by Logos.
// This is therefore a placeholder for functions defined in a future liblogos.a.

#endif
