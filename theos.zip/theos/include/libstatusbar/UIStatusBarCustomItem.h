#import <UIKit/UIStatusBarItem.h>

@interface UIStatusBarCustomItem : UIStatusBarItem

@end
