#import <UIKit/UIStatusBarItemView.h>

@class UIStatusBarItem;

@interface UIStatusBarCustomItemView : UIStatusBarItemView

- (UIStatusBarItem *)item;

@end
