#import "BBBulletin.h"

@interface BBBulletinRequest : BBBulletin

@end
