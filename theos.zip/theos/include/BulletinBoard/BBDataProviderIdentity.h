@interface BBDataProviderIdentity : NSObject

+ (id)identityForDataProvider:(id)arg1;
- (id)defaultSubsectionInfos;

@end
