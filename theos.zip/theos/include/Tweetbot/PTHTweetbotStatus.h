@interface PTHTweetbotStatus : NSObject

- (void)retweet:(id)sender;

@end
